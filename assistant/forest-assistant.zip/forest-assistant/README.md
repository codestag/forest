# Forest Assistant
A plugin to assist Forest theme in adding widgets.

### To use this follow the below steps
 1. Make sure you have [Forest Theme](https://codestag.com/themes/forest) installed and then clone or download this repo.
 2. Place the repo folder in your WordPress installations `wp-content/plugins/` folder.
 3. From your wp-admin Dashboard go to Plugins and activate `Forest Assistant` plugin.

#### Bugs
If you found a bug create a support request at [Codestag Support](https://codestag.com/support) or create an issue here.
