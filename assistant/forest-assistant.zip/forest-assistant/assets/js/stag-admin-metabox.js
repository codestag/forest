jQuery(document).ready(function($){
	$('.colorpicker').each(function(){
		$(this).wpColorPicker();
	});
});
